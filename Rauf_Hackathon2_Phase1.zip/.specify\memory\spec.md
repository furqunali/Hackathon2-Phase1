notepad main.py

